

<?php $__env->startSection('page_title','Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ps-5 pe-5 container-fluid">
        <h2><b>Login</b></h2>
         
        <div>            
            <?php if(isset($error)): ?>                                
                <p style="color: red"><?php echo e($error); ?></p>
            <?php else: ?> 
                <p>All admin must login!</p>
            <?php endif; ?> 
        </div>                      
        <hr>
        <h3>Email</h3>
        <input type="text" name="email" class="form-control"><br>
        <h3>Password</h3>
        <input type="text" name="password" class="form-control"><br>
        <br>
        <p style="text-align: center">
            <input type="submit" value="Login" class="btn btn-primary btn-lg">
        </p>        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\day18\resources\views/login.blade.php ENDPATH**/ ?>