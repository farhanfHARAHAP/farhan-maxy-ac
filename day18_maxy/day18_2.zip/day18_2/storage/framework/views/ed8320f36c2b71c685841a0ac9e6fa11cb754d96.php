<?php $__env->startSection('page_title','Purchase'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($mode)): ?>
        <?php if($mode == 'show'): ?>
            <style>
                .tb-delete {color: red}
            </style>
            <div>
                <a href="/admin/purchase"><h5 style="text-align: right">Back</h5></a>
                <h2><b>Purchase Logbook</b></h2>
                <p style="color: green">
                    <?php if(isset($success)): ?>
                        <?php echo e($success); ?>

                    <?php endif; ?>
                </p>
                <hr>
                
                <div>
                    <table style="max-width: auto">
                        <tr>
                            <td class="pe-4 pb-1"><b>No.</b></td>
                            <td class="pe-4 pb-1"><b>Date</b></td>
                            <td class="pe-4 pb-1"><b>Item</b></td>
                            <td class="pe-4 pb-1"><b>Quantity</b></td>
                            <td class="pe-4 pb-1"><b>Cost / Item</b></td>
                            <td class="pe-4 pb-1"><b>Cost Total</b></td>
                        </tr>
                        
                        <?php $count=1 ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="pe-4 pb-1"><?php echo e($count); ?></td>
                                <td class="pe-4 pb-1"><?php echo e($item['date']); ?></td>
                                <td class="pe-4 pb-1"><?php echo e($item['item']); ?></td>
                                <td class="pe-4 pb-1"><?php echo e($item['quantity']); ?></td>
                                <td class="pe-4 pb-1">Rp. <?php echo e($item['cost_item']); ?></td>
                                <td class="pe-4 pb-1">Rp. <?php echo e($item['cost_total']); ?></td>
                                <td class="pe-4 pb-1"><a href="/admin/purchase/edit/<?php echo e($item['id']); ?>">Edit</a></td>
                                <td class="pe-4 pb-1"><a href="/admin/purchase/delete/<?php echo e($item['id']); ?>" class="tb-delete">Delete</a></td>
                            </tr>
                            <?php $count += 1 ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        <?php if($mode == 'insert'): ?>
            <div>
                <a href="/admin/purchase"><h5 style="text-align: right">Back</h5></a>
                <h2><b>Insert Purchase Logbook</b></h2><hr>
                <p style="color: red">
                    <?php if(isset($error)): ?>
                        <?php echo e($error); ?>

                    <?php endif; ?>
                </p>
                <p style="color: green">
                    <?php if(isset($success)): ?>
                        <?php echo e($success); ?>

                    <?php endif; ?>
                </p>
                
                <div style="width: 70%">
                    <form action="/admin/purchase/insert/go" method="post">
                        <?php echo csrf_field(); ?>
                        <h4>Item Name</h4>
                        <input type="text" name="item" class="form-control"><br>
                        <h4>Quantity</h4>
                        <input type="text" name="quantity" class="form-control"><br>
                        <h4>Cost / Item (Rp.)</h4>
                        <input type="text" name="cost_item" class="form-control"><br>
                        <h4>Date</h4>
                        <input type="date" name="date" class="form-control"><br>
                        <p style="text-align: right">
                            <input type="submit" value="Insert" style="width: 30%" class="btn btn-primary">
                        </p>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <?php if($mode == 'edit'): ?>
            <div>
                <a href="/admin/purchase/show"><h5 style="text-align: right">Back</h5></a>
                <h2><b>Edit Purchase Logbook</b></h2><hr>
                <p style="color: red">
                    <?php if(isset($error)): ?>
                        <?php echo e($error); ?>

                    <?php endif; ?>
                </p>
                <p style="color: green">
                    <?php if(isset($success)): ?>
                        <?php echo e($success); ?>

                    <?php endif; ?>
                </p>
                
                <div style="width: 70%;">
                    <form action="/admin/purchase/edit/go" method="post">
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4>You are editing log (id)</h4>
                        <input type="text" class="form-control" value="<?php echo e($item['id']); ?>" disabled><br>
                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                        <h4>Item Name</h4>
                        <input type="text" name="item" class="form-control" value="<?php echo e($item['item']); ?>"><br>
                        <h4>Quantity</h4>
                        <input type="text" name="quantity" class="form-control" value="<?php echo e($item['quantity']); ?>"><br>
                        <h4>Cost / Item (Rp.)</h4>
                        <input type="text" name="cost_item" class="form-control" value="<?php echo e($item['cost_item']); ?>"><br>
                        <h4>Date</h4>
                        <input type="date" name="date" class="form-control" value="<?php echo e($item['date']); ?>"><br>
                        <p style="text-align: right">
                            <input type="submit" value="Edit" style="width: 30%" class="btn btn-primary">
                        </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <?php else: ?>
            <div style="width: 70%">
                <h2><b>Purchase Menu</b></h2>
                <h2 style="text-align: right">Rp. <?php echo e($cost); ?></h2>
                <hr>
                <a href="/admin/purchase/show"><h3>Show Purchase Logbook</h3></a>
                <a href="/admin/purchase/insert"><h3>Insert Purchase Log</h3></a>
            </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\day18\resources\views/purchase.blade.php ENDPATH**/ ?>