<?php $__env->startSection('page_title','Register'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ps-5 pe-5 container-fluid">
        <h2><b>Register</b></h2>
        
        <div>
            <?php if(isset($error)): ?>
                <p style="color: red"><?php echo e($error); ?></p>
            <?php endif; ?>
            <?php if(isset($success)): ?>
                <p style="color: green"><?php echo e($success); ?></p>
            <?php endif; ?>
            <p>Get your administrator account!</p>
        </div>
        <hr>
        <form action="/register/go" method="post">
            <?php echo csrf_field(); ?>
            <h3>Full Name</h3>
            <input type="text" name="name" class="form-control" maxlength="255">
            <p>Max 255 Character</p><br>
            <h3>Email</h3>
            <input type="email" name="email" class="form-control" maxlength="255">
            <p>Max 255 Character</p><br>
            <h3>Password</h3>
            <input type="password" name="password" class="form-control">
            <p>Min 8 Character</p><br>
            <br>
            <p style="text-align: center">
                <input type="submit" value="Register" class="btn btn-primary btn-lg">
            </p>
            <p style="text-align: center">Login <a href="/login">here.</a></p>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\day18_2\resources\views/register.blade.php ENDPATH**/ ?>