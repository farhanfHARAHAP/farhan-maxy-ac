<?php $__env->startSection('page_title','Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ps-5 pe-5 pt-5" style="text-align: center">
        <img src="<?php echo e(asset('img/flower.jpg')); ?>" style="max-width: 500px">
        <br><br>
        <h3>Sales: Rp. <?php echo e($price); ?> | Purchases: Rp. <?php echo e($cost); ?></h3>
        <?php if($cost > $price): ?>
        <h3 style="color: red">-Rp. <?php echo e($cost-$price); ?></h3>
        <?php endif; ?>
        <?php if($price > $cost): ?>
        <h3 style="color: green">-Rp. <?php echo e($price-$cost); ?></h3>
        <?php endif; ?>
        <?php if($price == $cost): ?>
        <h3 style="color: blue">DRAW</h3>
        <?php endif; ?>
        <br><br>
        <h2><b>Hello username! </b></h2>
        <hr>
        <p>Please bring your to-do before you begin working!</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\day18_2\resources\views/home.blade.php ENDPATH**/ ?>